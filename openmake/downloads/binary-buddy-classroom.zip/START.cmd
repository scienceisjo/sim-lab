@echo off
set "BINARY_BUDDY_ROOT=%~dp0"
powershell.exe -NoLogo -NoProfile -Command "& ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $env:BINARY_BUDDY_ROOT 'serve-local.ps1'))))"
pause
