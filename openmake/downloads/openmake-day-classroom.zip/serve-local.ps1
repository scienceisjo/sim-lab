﻿param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$lessonBase = if ($env:OPENMAKE_DAY_ROOT) { $env:OPENMAKE_DAY_ROOT } else { $PSScriptRoot }
$lessonRoot = [IO.Path]::GetFullPath($lessonBase).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
$lessonListener = $null
foreach ($lessonPort in 7136..7199) {
    try {
        $lessonListener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $lessonPort)
        $lessonListener.Start()
        break
    } catch {
        $lessonListener = $null
    }
}
if ($null -eq $lessonListener) { throw '사용 가능한 수업용 포트가 없습니다. 7136~7199 포트를 확인해 주세요.' }
$lessonUrl = "http://127.0.0.1:$lessonPort/"
Write-Host "오픈메이크데이: $lessonUrl"
Write-Host '이 창을 닫으면 로컬 서버가 종료됩니다. 이 주소는 현재 컴퓨터에서만 열립니다.'
if (-not $NoBrowser) { Start-Process $lessonUrl }
try {
    while ($true) {
        $lessonClient = $lessonListener.AcceptTcpClient()
        try {
            $lessonStream = $lessonClient.GetStream()
            $lessonStream.ReadTimeout = 4000
            $lessonBuffer = New-Object byte[] 8192
            $lessonRequest = ''
            do {
                $lessonCount = $lessonStream.Read($lessonBuffer, 0, $lessonBuffer.Length)
                if ($lessonCount -eq 0) { break }
                $lessonRequest += [Text.Encoding]::ASCII.GetString($lessonBuffer, 0, $lessonCount)
            } while (-not $lessonRequest.Contains("`r`n`r`n") -and $lessonRequest.Length -lt 16384)
            $lessonFirst = ($lessonRequest -split "`r`n")[0] -split ' '
            $lessonStatus = '200 OK'
            $lessonType = 'text/html; charset=utf-8'
            $lessonBody = [Text.Encoding]::UTF8.GetBytes('')
            if ($lessonFirst[0] -ne 'GET') { $lessonStatus = '405 Method Not Allowed' }
            else {
                $lessonName = [Uri]::UnescapeDataString(($lessonFirst[1] -split '\?')[0]).TrimStart('/')
                if ($lessonName -eq '' -or $lessonName.EndsWith('/')) { $lessonName += 'index.html' }
                $lessonFile = [IO.Path]::GetFullPath([IO.Path]::Combine($lessonRoot, $lessonName))
                if (-not $lessonFile.StartsWith($lessonRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { $lessonStatus = '403 Forbidden' }
                elseif (-not [IO.File]::Exists($lessonFile)) { $lessonStatus = '404 Not Found' }
                else {
                    $lessonBody = [IO.File]::ReadAllBytes($lessonFile)
                    switch ([IO.Path]::GetExtension($lessonFile).ToLowerInvariant()) {
                        '.pdf' { $lessonType = 'application/pdf' }
                        '.png' { $lessonType = 'image/png' }
                        '.webp' { $lessonType = 'image/webp' }
                        '.svg' { $lessonType = 'image/svg+xml' }
                        '.zip' { $lessonType = 'application/zip' }
                        '.txt' { $lessonType = 'text/plain; charset=utf-8' }
                        '.json' { $lessonType = 'application/json; charset=utf-8' }
                        '.html' { $lessonType = 'text/html; charset=utf-8' }
                        default { $lessonType = 'application/octet-stream' }
                    }
                }
            }
            $lessonHeader = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $lessonStatus`r`nContent-Type: $lessonType`r`nContent-Length: $($lessonBody.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n")
            $lessonStream.Write($lessonHeader, 0, $lessonHeader.Length)
            $lessonStream.Write($lessonBody, 0, $lessonBody.Length)
        } catch {
            Write-Verbose '닫힌 연결을 건너뜁니다.'
        } finally {
            $lessonClient.Close()
        }
    }
} finally {
    $lessonListener.Stop()
}
