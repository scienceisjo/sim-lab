@echo off
set "OPENMAKE_DAY_ROOT=%~dp0"
powershell.exe -NoLogo -NoProfile -Command "& ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $env:OPENMAKE_DAY_ROOT 'serve-local.ps1'))))"
pause
